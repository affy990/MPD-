package com.example.ahmad_afaq_s1625481.mpdcoursework_aa.utils;

import java.util.ArrayList;

public interface Async {
    void processFinish(ArrayList<?> output);
}
