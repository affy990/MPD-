package com.example.ahmad_afaq_s1625481.mpdcoursework_aa.utils;


/*  Created by: Afaq Ahmad
        Student number: S1625481
*/
import java.io.InputStream;
import java.util.ArrayList;

abstract class XmlToJavaParser {

    public abstract ArrayList<?> xmlParser(InputStream inputStream);
}
